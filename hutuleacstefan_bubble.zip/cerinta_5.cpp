// parcurgerea sirului unind bula prin index
#include<iostream>
#include<conio.h>

int n1,n2;
int V[100];
using namespace std;

int main(){
    cout<<"n = ";cin>>n1;
    for(int i=1;i<=n1;i++){V[i]=i;}

    n2=n1;
    while(n2){
        for(int i=1;i<=n1;i++){
            if(i!=0){
                swap(V[i],V[i+1]);}
            if(i==n1){
                swap(V[i+1],V[i]);}
            cout<<V[i]<<" ";}
        cout<<endl;
        n2--;}
    _getche();
    return 1;}

